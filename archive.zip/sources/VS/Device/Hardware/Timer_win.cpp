// 2024/03/02 13:21:01 (c) Aleksandr Shevchenko e-mail : Sasha7b9@tut.by
#include "defines.h"
#include "Hardware/Timer.h"


void TimeMeterMS::Reset()
{

}


uint TimeMeterMS::ElapsedTime() const
{
    return 0;
}
