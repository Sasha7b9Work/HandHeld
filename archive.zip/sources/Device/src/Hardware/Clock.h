// 2024/03/06 08:28:47 (c) Aleksandr Shevchenko e-mail : Sasha7b9@tut.by
#pragma once
#include "Display/Display.h"


namespace Clock
{
    void Draw(int x, int y, const Color & = Color::NUMBER);
}
