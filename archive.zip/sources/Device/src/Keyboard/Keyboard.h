// 2024/03/01 22:58:09 (c) Aleksandr Shevchenko e-mail : Sasha7b9@tut.by
#pragma once


namespace Keyboard
{
    void Init();

    void Update();
}
