// 2024/03/01 22:29:45 (c) Aleksandr Shevchenko e-mail : Sasha7b9@tut.by
#pragma once


namespace Device
{
    void Init();

    void Update();
}
