// 2024/03/01 23:02:03 (c) Aleksandr Shevchenko e-mail : Sasha7b9@tut.by
#include "defines.h"
#include "Menu/Menu.h"


void Menu::Init()
{

}


void Menu::Update()
{

}


void Menu::ShortPress()
{

}


void Menu::LongPress()
{

}
