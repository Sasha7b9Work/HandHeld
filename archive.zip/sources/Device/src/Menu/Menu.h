// 2024/03/01 22:58:42 (c) Aleksandr Shevchenko e-mail : Sasha7b9@tut.by
#pragma once


namespace Menu
{
    void Init();

    void Update();

    void ShortPress();

    void LongPress();
}
